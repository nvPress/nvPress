<template>
	<div class="grid cols-2 xxs:cols-1 xs:cols-1 xl:cols-3 g-10">
		<slot />
	</div>
</template>

<style scoped>
div {
	margin: 1.5em 0 3em;
}
</style>