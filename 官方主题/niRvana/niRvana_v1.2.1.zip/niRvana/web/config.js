var __niRvana_config__ = {
	api:"",
	emojis: [
		"😀","😁","😆","😅","😂","🙃",
		"😉","😊","😍","😘","😋","🤑",
		"🤐","🙄","😪","😴","😎","😈"
	],
	avatars: [
		"/avatars/avatar-01.png",
		"/avatars/avatar-02.png",
		"/avatars/avatar-03.png",
		"/avatars/avatar-04.png",
		"/avatars/avatar-05.png",
		"/avatars/avatar-06.png",
		"/avatars/avatar-07.png",
		"/avatars/avatar-08.png"
	]
}