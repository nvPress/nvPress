module.exports = ({echo,post,post_slug,comment_page})=>{
	var site_name = get_option('nv_site_name','nvPress');
	var title = `${post.title} - ${site_name}`;
	var description = post.excerpt;
	var thumbnail_url = get_post_meta(post.id,"_nv_thumbnail");
	require('./function-ssr-header')({echo,title,description,image:thumbnail_url});
	echo(`
		<article>
			<h1>${post.title}</h1>
	`);
	if (thumbnail_url) {
		echo(`<img src='${thumbnail_url}' />`);
	}
	require('./function-ssr-block-renderer')({echo,blocks:post.content.blocks});
	echo(`</article>`);
	require('./function-ssr-footer')({echo});
}