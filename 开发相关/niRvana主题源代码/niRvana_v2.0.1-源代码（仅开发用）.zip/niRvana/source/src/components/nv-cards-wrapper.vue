<template>
	<div class="grid cols-2 xs:cols-3 sm:cols-3 md:cols-3 lg:cols-3 xl:cols-4 xxs:gx-8 xxs:gy-16 xs:gx-8 xs:gy-16 gx-16 gy-30">
		<slot />
	</div>
</template>

<style scoped>
div {
	margin: 2.125em 0 3em;
}
</style>