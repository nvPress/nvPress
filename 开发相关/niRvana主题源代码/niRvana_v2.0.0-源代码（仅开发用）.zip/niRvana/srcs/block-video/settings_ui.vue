<template>
	<div v-if="url || iframe">
		<div class="tune-buttons border-bottom flex-wrap" style="min-width: 146px">
			<nvTooltip v-if="url">
				<template #trigger>
					<button
					class="cdx-settings-button"
					:class="{'cdx-settings-button--active': align == 'left'}"
					@click="align=align=='left'?'':'left'"
					>
						<svg xmlns="http://www.w3.org/2000/svg" style="width: 14px" viewBox="0 0 448 512"><path d="M256 96H32C14.33 96 0 81.67 0 64C0 46.33 14.33 32 32 32H256C273.7 32 288 46.33 288 64C288 81.67 273.7 96 256 96zM256 352H32C14.33 352 0 337.7 0 320C0 302.3 14.33 288 32 288H256C273.7 288 288 302.3 288 320C288 337.7 273.7 352 256 352zM0 192C0 174.3 14.33 160 32 160H416C433.7 160 448 174.3 448 192C448 209.7 433.7 224 416 224H32C14.33 224 0 209.7 0 192zM416 480H32C14.33 480 0 465.7 0 448C0 430.3 14.33 416 32 416H416C433.7 416 448 430.3 448 448C448 465.7 433.7 480 416 480z"/></svg>
					</button>
				</template>
				左对齐
			</nvTooltip>
			<nvTooltip v-if="url">
				<template #trigger>
					<button
					class="cdx-settings-button"
					:class="{'cdx-settings-button--active': align == 'center'}"
					@click="align=align=='center'?'':'center'"
					>
						<svg xmlns="http://www.w3.org/2000/svg" style="width: 14px" viewBox="0 0 448 512"><path d="M320 96H128C110.3 96 96 81.67 96 64C96 46.33 110.3 32 128 32H320C337.7 32 352 46.33 352 64C352 81.67 337.7 96 320 96zM416 224H32C14.33 224 0 209.7 0 192C0 174.3 14.33 160 32 160H416C433.7 160 448 174.3 448 192C448 209.7 433.7 224 416 224zM0 448C0 430.3 14.33 416 32 416H416C433.7 416 448 430.3 448 448C448 465.7 433.7 480 416 480H32C14.33 480 0 465.7 0 448zM320 352H128C110.3 352 96 337.7 96 320C96 302.3 110.3 288 128 288H320C337.7 288 352 302.3 352 320C352 337.7 337.7 352 320 352z"/></svg>
					</button>
				</template>
				居中
			</nvTooltip>
			<nvTooltip v-if="url">
				<template #trigger>
					<button
					class="cdx-settings-button"
					:class="{'cdx-settings-button--active': align == 'right'}"
					@click="align=align=='right'?'':'right'"
					>
						<svg xmlns="http://www.w3.org/2000/svg" style="width: 14px" viewBox="0 0 448 512"><path d="M416 96H192C174.3 96 160 81.67 160 64C160 46.33 174.3 32 192 32H416C433.7 32 448 46.33 448 64C448 81.67 433.7 96 416 96zM416 352H192C174.3 352 160 337.7 160 320C160 302.3 174.3 288 192 288H416C433.7 288 448 302.3 448 320C448 337.7 433.7 352 416 352zM0 192C0 174.3 14.33 160 32 160H416C433.7 160 448 174.3 448 192C448 209.7 433.7 224 416 224H32C14.33 224 0 209.7 0 192zM416 480H32C14.33 480 0 465.7 0 448C0 430.3 14.33 416 32 416H416C433.7 416 448 430.3 448 448C448 465.7 433.7 480 416 480z"/></svg>
					</button>
				</template>
				右对齐
			</nvTooltip>
			<nvTooltip>
				<template #trigger>
					<button
					class="cdx-settings-button"
					:class="{'cdx-settings-button--active': align == 'full'}"
					@click="align=align=='full'?'':'full'"
					>
						<svg xmlns="http://www.w3.org/2000/svg" style="width: 14px" viewBox="0 0 448 512"><path d="M128 32H32C14.31 32 0 46.31 0 64v96c0 17.69 14.31 32 32 32s32-14.31 32-32V96h64c17.69 0 32-14.31 32-32S145.7 32 128 32zM416 32h-96c-17.69 0-32 14.31-32 32s14.31 32 32 32h64v64c0 17.69 14.31 32 32 32s32-14.31 32-32V64C448 46.31 433.7 32 416 32zM128 416H64v-64c0-17.69-14.31-32-32-32s-32 14.31-32 32v96c0 17.69 14.31 32 32 32h96c17.69 0 32-14.31 32-32S145.7 416 128 416zM416 320c-17.69 0-32 14.31-32 32v64h-64c-17.69 0-32 14.31-32 32s14.31 32 32 32h96c17.69 0 32-14.31 32-32v-96C448 334.3 433.7 320 416 320z"/></svg>
					</button>
				</template>
				全宽放大
			</nvTooltip>
			<nvTooltip v-if="url">
				<template #trigger>
					<button
					class="cdx-settings-button"
					:class="{'cdx-settings-button--active': autoplay}"
					@click="autoplay=!autoplay"
					>
						<svg xmlns="http://www.w3.org/2000/svg" style="width: 14px" viewBox="0 0 512 512"><path d="M188.3 147.1C195.8 142.8 205.1 142.1 212.5 147.5L356.5 235.5C363.6 239.9 368 247.6 368 256C368 264.4 363.6 272.1 356.5 276.5L212.5 364.5C205.1 369 195.8 369.2 188.3 364.9C180.7 360.7 176 352.7 176 344V167.1C176 159.3 180.7 151.3 188.3 147.1V147.1zM512 256C512 397.4 397.4 512 256 512C114.6 512 0 397.4 0 256C0 114.6 114.6 0 256 0C397.4 0 512 114.6 512 256zM256 48C141.1 48 48 141.1 48 256C48 370.9 141.1 464 256 464C370.9 464 464 370.9 464 256C464 141.1 370.9 48 256 48z"/></svg>
					</button>
				</template>
				自动播放
			</nvTooltip>
			<nvTooltip v-if="url">
				<template #trigger>
					<button
					class="cdx-settings-button"
					:class="{'cdx-settings-button--active': controls}"
					@click="controls=!controls"
					>
						<svg xmlns="http://www.w3.org/2000/svg" style="width: 14px" viewBox="0 0 448 512"><path d="M208 288C199.2 288 192 295.2 192 304v96C192 408.8 199.2 416 208 416s16-7.164 16-16v-96C224 295.2 216.8 288 208 288zM272 288C263.2 288 256 295.2 256 304v96c0 8.836 7.162 16 15.1 16S288 408.8 288 400l-.0013-96C287.1 295.2 280.8 288 272 288zM376.9 201.2c-13.74-17.12-34.8-27.45-56.92-27.45h-13.72c-3.713 0-7.412 .291-11.07 .8652C282.7 165.1 267.4 160 251.4 160h-11.44V72c0-39.7-32.31-72-72.01-72c-39.7 0-71.98 32.3-71.98 72v168.5C84.85 235.1 75.19 235.4 69.83 235.4c-44.35 0-69.83 37.23-69.83 69.85c0 14.99 4.821 29.51 13.99 41.69l78.14 104.2C120.7 489.3 166.2 512 213.7 512h109.7c6.309 0 12.83-.957 18.14-2.645c28.59-5.447 53.87-19.41 73.17-40.44C436.1 446.3 448 416.2 448 384.2V274.3C448 234.6 416.3 202.3 376.9 201.2zM400 384.2c0 19.62-7.219 38.06-20.44 52.06c-12.53 13.66-29.03 22.67-49.69 26.56C327.4 463.6 325.3 464 323.4 464H213.7c-32.56 0-63.65-15.55-83.18-41.59L52.36 318.2C49.52 314.4 48.02 309.8 48.02 305.2c0-16.32 14.5-21.75 21.72-21.75c4.454 0 12.01 1.55 17.34 8.703l28.12 37.5c3.093 4.105 7.865 6.419 12.8 6.419c11.94 0 16.01-10.7 16.01-16.01V72c0-13.23 10.78-24 23.1-24c13.22 0 24 10.77 24 24v130.7c0 6.938 5.451 16.01 16.03 16.01C219.5 218.7 220.1 208 237.7 208h13.72c21.5 0 18.56 19.21 34.7 19.21c8.063 0 9.805-5.487 20.15-5.487h13.72c26.96 0 17.37 27.43 40.77 27.43l14.07-.0037c13.88 0 25.16 11.28 25.16 25.14V384.2zM336 288C327.2 288 320 295.2 320 304v96c0 8.836 7.164 16 16 16s16-7.164 16-16v-96C352 295.2 344.8 288 336 288z"/></svg>
					</button>
				</template>
				显示播放控件
			</nvTooltip>
			<nvTooltip v-if="url">
				<template #trigger>
					<button
					class="cdx-settings-button"
					:class="{'cdx-settings-button--active': loop}"
					@click="loop=!loop"
					>
						<svg xmlns="http://www.w3.org/2000/svg" style="width: 14px" viewBox="0 0 512 512"><path d="M0 224c0 17.7 14.3 32 32 32s32-14.3 32-32c0-53 43-96 96-96H320v32c0 12.9 7.8 24.6 19.8 29.6s25.7 2.2 34.9-6.9l64-64c12.5-12.5 12.5-32.8 0-45.3l-64-64c-9.2-9.2-22.9-11.9-34.9-6.9S320 19.1 320 32V64H160C71.6 64 0 135.6 0 224zm512 64c0-17.7-14.3-32-32-32s-32 14.3-32 32c0 53-43 96-96 96H192V352c0-12.9-7.8-24.6-19.8-29.6s-25.7-2.2-34.9 6.9l-64 64c-12.5 12.5-12.5 32.8 0 45.3l64 64c9.2 9.2 22.9 11.9 34.9 6.9s19.8-16.6 19.8-29.6V448H352c88.4 0 160-71.6 160-160z"/></svg>
					</button>
				</template>
				循环播放
			</nvTooltip>
			<nvTooltip>
				<template #trigger>
					<button
					class="cdx-settings-button"
					@click="url='';iframe='';ratio=1.778"
					>
					<svg xmlns="http://www.w3.org/2000/svg" style="width: 18px" viewBox="0 0 20 20">
						<path id="undo" class="cls-1" d="M8.894,9.232H3.33A0.333,0.333,0,0,1,3,8.9V3.337A0.333,0.333,0,0,1,3.33,3H4.663A0.333,0.333,0,0,1,5,3.337V5.505a6.885,6.885,0,1,1,.495,9.708,0.334,0.334,0,0,1-.013-0.484l0.943-.943a0.333,0.333,0,0,1,.455-0.015,4.886,4.886,0,1,0-.713-6.539H8.894a0.333,0.333,0,0,1,.333.333V8.9a0.333,0.333,0,0,1-.333.333h0Z"/>
					</svg>
					</button>
				</template>
				重新选择视频
			</nvTooltip>
		</div>
		<div class="tune-box border-bottom" v-if="iframe">
			<div class="title">宽高比</div>
			<nvInputNumber :precision="3" :min='0.1' :max="10" v-model:value="ratio" style="width: 130px" />
		</div>
	</div>
</template>
<script>
export default {
	name: 'pandastudio-video-settings',
	components:{
		nvInputNumber: nv.components.inputNumber,
		nvTooltip: nv.components.tooltip,
	},
	data(){return{
		align: '',
		ratio: 1.778,
		url: '',
		iframe: '',
		autoplay: false,
		controls: true,
		loop: false,
	}},
	mounted() {
		// 加载默认数据
		nv.block.loadDefaultData.bind(this)();
	},
}
</script>
<style scoped>
</style>