<template>
	<div class="grid cols-2 xxs:cols-1 xs:cols-1 md:cols-3 lg:cols-3 xl:cols-4 g-10">
		<slot />
	</div>
</template>