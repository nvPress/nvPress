var path = require('path');

// 在 init_express 钩子调用的时候操作：
add_action('init_express',()=>{

	// 为聊天室注册一个前台访问页面文件夹
	register_static_url('/chatting-room', path.join(__dirname,"./web/") );
	
	// 访问页面可以直接跳转到index.html
	add_filter('rewrite_rules_array',arr=>{
		arr.push({
			from: /\/chatting-room/, to: '/chatting-room/index.html'
		})
		return arr;
	});

	// 定义用户起始数量
	var userID = 0;
	var users = [];
	// 为聊天室注册一个Socket地址，用于通讯
	register_socket_route('panda/chatting-room','socket-api',{
		callback(ws,req) {
			// 新用户连接到服务器，保存这个用户
			var user = {id: ++userID, ws};
			users.push(user);
			// 发送所有人
			users.forEach(({ws})=>{
				ws.send(`欢迎新用户${user.id}，当前在线人数：${users.length}`);
			});

			ws.on('message',data => {
				// 收到消息，转发给所有人
				users.forEach(({ws})=>{
					ws.send(`用户${user.id} ：${data}`);
				})
			})

			ws.on('close', () => {
				// 移除这个用户
				var user_index = users.indexOf(user);
				if (user_index >= 0) {

					users.splice(user_index,1);

					// 发送所有人
					users.forEach(({ws})=>{
						ws.send(`用户${user.id}，已离开聊天室`);
					});
				}
			});
		}
	});
});