var inputElement = document.querySelector('input');

var ws = new WebSocket(
	(window.location.protocol === 'https:' ? 'wss://' : 'ws://') +
	window.location.host + '/panda/chatting-room/socket-api'
	);

ws.addEventListener('message', event=> {
	var p = document.createElement('p');
	p.innerText = event.data;
    inputElement.after(p)
});

inputElement.addEventListener('keydown',event=>{
	if (event.keyCode == 13) {
		ws.send(inputElement.value)
		inputElement.value = ''
	}
})