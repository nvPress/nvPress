nv_render_assistant({
	rendering_mode: "CSR",
	root_folder: get_theme_path("./dist/")
})