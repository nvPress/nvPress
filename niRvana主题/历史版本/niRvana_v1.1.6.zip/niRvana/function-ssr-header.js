var fs = require('fs');
var path = require('path');

var show_category_list = ()=>{
	return query_terms({
		taxonomy: 'category',
	}).map(cat=>{
		return ` | <a href="/category/${cat.slug}">${cat.name}</a>`
	})
	.join('');
}

var theme_scripts_and_styles = fs.readFileSync( path.join(__dirname,"./web/application.html")  );

module.exports = ({title,echo,image})=>{
	var description = get_option('nv_site_description','');
	var logo = get_option('niRvana_logo_url');
	var favicon = get_option('niRvana_favicon_32');
	var apple_touch_icon = get_option('niRvana_apple_touch_icon');

	echo(`
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no,viewport-fit=cover">
	<title>${title}</title>
	<meta description="${description}">
	<meta itemprop="name" content="${title}" />
	<meta itemprop="image" content="${image || apple_touch_icon || favicon || logo}" />
	<meta name="description" itemprop="description" content="${description}">
	${favicon ? `<link rel="shortcut icon" href="${favicon}" sizes="32x32">` : ''}
	${apple_touch_icon ? `<link rel="apple-touch-icon" href="${apple_touch_icon}">` : ''}
	<script type="text/javascript" src="/config.js"></script>
	${theme_scripts_and_styles}
</head>
<body>
	<div id="app">
		<noscript>
		<nav>
		<a href="/" rel="home">${logo ? `<img rel="logo" height="50" src="${logo}" />` : ''}</a> | 
		<a href="/articles">全部文章</a>
		${show_category_list()}
		</nav>
	`);
}