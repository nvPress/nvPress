function get_description(post) {
	if (post.excerpt) {
		return post.excerpt;
	}
	return post.content.blocks
	.filter(block=>block.type == 'paragraph')
	.map(block=>block.data.text)
	.join('')
	.substr(0,160);
}

module.exports = ({echo,post,post_slug,comment_page})=>{
	var site_name = get_option('nv_site_name','nvPress');
	var title = `${post.title} - ${site_name}`;
	var description = get_description(post);
	var thumbnail_url = get_post_meta(post.id,"_nv_thumbnail");
	require('./function-ssr-header')({echo,post,title,description,image:thumbnail_url});
	echo(`<article>`);
	if (thumbnail_url) {
		echo(`<img src='${thumbnail_url}' />`);
	}
	require('./function-ssr-block-renderer')({echo,blocks:post.content.blocks});
	echo(`</article>`);
	require('./function-ssr-footer')({echo});
}