var path = require('path');

register_editor_block('pandastudio/panel',['page','article'],'/srcs/block-panel/index.js');
register_editor_block('pandastudio/tip',['page','article'],'/srcs/block-tip/index.js');
register_editor_block('pandastudio/collapse',['page','article'],'/srcs/block-collapse/index.js');
register_editor_block('pandastudio/columns',['page','article'],'/srcs/block-columns/index.js');