module.exports = ({echo})=>{
	echo(`</body></html>`);
}