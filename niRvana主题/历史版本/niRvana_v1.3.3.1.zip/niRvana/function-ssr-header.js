var fs = require('fs');
var path = require('path');

var show_category_list = ()=>{
	return query_terms({
		taxonomy: 'category',
	}).map(cat=>{
		return ` | <a href="/category/${cat.slug}">${cat.name}</a>`
	})
	.join('');
}

var theme_scripts_and_styles = fs.readFileSync( path.join(__dirname,"./web/application.html")  );

module.exports = ({title,post,echo,image,description})=>{
	var site_name = get_option('nv_site_name','nvPress');
	var description = description || `欢迎光临 ${site_name}，${get_option('nv_site_description','')}`;
	var logo = get_option('niRvana_logo_url');
	var favicon = get_option('niRvana_favicon_32');
	var apple_touch_icon = get_option('niRvana_apple_touch_icon');
	echo(`
<!DOCTYPE html>
<html lang="zh-cn">
<head>
	<meta charset="UTF-8">
	<title>${esc_html(title)}</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no,viewport-fit=cover">
	<meta description="${esc_html(strip_tags(description))}">
	<meta itemprop="name" content="${esc_html(title)}" />
	<meta itemprop="image" content="${image || apple_touch_icon || favicon || logo}" />
	<meta name="description" itemprop="description" content="${esc_html(strip_tags(description))}">
	${favicon ? `<link rel="shortcut icon" href="${favicon}" sizes="32x32">` : ''}
	${apple_touch_icon ? `<link rel="apple-touch-icon" href="${apple_touch_icon}">` : ''}
	<script type="text/javascript" src="/config.js"></script>
	${get_option('niRvana_custom_head','')}
	${theme_scripts_and_styles}
</head>
<body>
	<h1>${esc_html( post ? post.title : title )}</h1>
	<div id="app">
		<noscript>
		<nav>
		<a href="/" rel="home">${logo ? `<img rel="logo" height="50" src="${logo}" />` : ''}</a> | 
		<a href="/articles">全部文章</a>
		${show_category_list()}
		</nav>
	`);
}