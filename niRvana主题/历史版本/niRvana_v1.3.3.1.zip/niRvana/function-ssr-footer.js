module.exports = ({echo})=>{
	echo(`</noscript></div></body></html>`);
}