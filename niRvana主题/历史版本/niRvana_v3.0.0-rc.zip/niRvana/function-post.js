// 列表页相关
var path = require('path');
var fs = require('fs');

register_rest_route('nirvana','relate-post',{
	methods: 'post',
	callback(data,req) {
		var {id,categoryIDs,tagIDs} = data;
		var posts = query_posts({
			post_type: 'article',
			status: 'publish',
			post_not_in: [id],
			tax_query: {
				relation: 'OR',
				opts: [{
					taxonomy: 'category',
					terms: categoryIDs,
					operator: 'IN'
				},{
					taxonomy: 'tag',
					terms: tagIDs,
					operator: 'IN'
				}]
			},
			orderby: 'rand',
			posts_per_page: 4
		});
		return posts.data.map(post=>nirvana_lite_post(post));
	}
});

register_rest_route('nirvana','post-like',{
	methods: 'post',
	callback(data,req) {
		var {id} = data;
		var likes = get_post_meta(id,'likes') || 0;
		likes = parseInt(likes+1) || 1;
		update_post_meta(id,'likes',likes);
		return likes;
	}
});

register_rest_route('nirvana','post-view',{
	methods: 'post',
	callback(data,req) {
		var {id} = data;
		var views = get_post_meta(id,'views') || 0;
		views = parseInt(views+1) || 1;
		update_post_meta(id,'views',views);
		return views;
	}
});


var fix_block_data = (sth, fix_handlers) => {
	var object_is_editor = obj => obj && Array.isArray(obj.blocks) && obj.blocks.every(block=>block.id && block.type && block.data)
	var find_target_in = arr_or_obj =>{
		if (!arr_or_obj) {return;}

		if ( Array.isArray(arr_or_obj) ) {
			arr_or_obj.forEach((item,index)=>{
				if (object_is_editor(item)) {
					item.blocks.forEach(block=>{
						if ( fix_handlers[block.type] ) {
							fix_handlers[block.type](block);
						} else {
							find_target_in(block)
						}
					})
				} else {
					find_target_in(item)
				}
			})
		} else if(typeof(arr_or_obj) == 'object') {
			Object.keys(arr_or_obj).forEach(key=>{
				var item = arr_or_obj[key];
				if (object_is_editor(item)) {
					item.blocks.forEach(block=>{
						if ( fix_handlers[block.type] ) {
							fix_handlers[block.type](block);
						} else {
							find_target_in(block)
						}
					})
				} else {
					find_target_in(item)
				}
			})
		}
	}
	
	if ( object_is_editor(sth) ) {
		sth.blocks.forEach(block=>{
			if ( fix_handlers[block.type] ) {
				fix_handlers[block.type](block);
			} else {
				find_target_in(block)
			}
		})
	}
	find_target_in(sth);
}

// 需要对文章结果进行处理。以实现评论后可见
add_filter('rest_send_post:/nv/front-stage/get-post', (send_data, req)=>{
	if ( is_nv_error(send_data) ) {
		return send_data;
	}

	// 处理评论可见
	var current_user_email = get_user_by_nonce(req.headers.nvnonce).email || req.body.email;
	var is_current_user_replied = current_user_email
								?
								query_comments({
									email: current_user_email,
									post: send_data.id
								}).pagination.total
								: false;
	// 处理文章 content，并且循环处理子block。方法可能有性能问题，待优化
	fix_block_data(send_data.content,{
		'pandastudio/download'(block) {
			if (block.data.need_reply && !is_current_user_replied) {
				block.data.url = '';
				block.data.links.forEach(link=>{
					link.url = '';
				})
			} else {
				block.data.need_reply = false;
			}
		}
	})
	return send_data;
})