/*
=========================================================
SEO：专为搜索引擎处理ssr。不是搜索引擎的UA则使用前端渲染
=========================================================
*/

var fs = require('fs');
var path = require('path');

// 读取SPA页面
var spa_html = fs.readFileSync( path.join(__dirname,"./web/application.html")  );

// 搜索引擎
var is_search_engin = req => {
	var search_charactors = ['baiduspider','baiduboxapp','googlebot','360spider','sogouspider','sogou web spider','yisouspider','bingbot','bingpreview','youdaobot','yodaobot','msnbot','yahoo!','yandexbot','dnspod-monitor','mj12bot','semrushbot','bytespider','aspiegel'];
	var ua = req.headers['user-agent'].toLowerCase();
	return search_charactors.some(char=>ua.includes(char));
}

// 静态资源
register_static_url('/', path.join(__dirname,"./web/") );

// 渲染路径控制
add_action('register_server_side_render_router',express=>{
	// 由于使用了SSR，所以每个可能的地址都要判定一遍
	express.get('/', (req,res,next)=>{
		res.type("text/html");
		// res.send( "进来了：/" );
		res.send( is_search_engin(req) ? ssr_frontpage() : spa_html );
		return;
	})
	express.get('/articles', (req,res,next)=>{
		res.type("text/html");
		// res.send( "进来了" );
		res.send( is_search_engin(req) ? ssr_articles({current_page: 1}) : spa_html );
		return;
	})
	express.get('/articles/page/:current_page', (req,res,next)=>{
		var current_page = req.params.current_page;
		res.type("text/html");
		// res.send( "进来了" );
		res.send( is_search_engin(req) ? ssr_articles({current_page}) : spa_html );
		return;
	})
	express.get('/:post_slug', (req,res,next)=>{
		var post_slug = req.params.post_slug;
		if (post_slug.includes('.')) {
			next();
		} else {
			// 这是文章页
			res.type("text/html");
			// res.send( "进来了：post" );
			res.send( is_search_engin(req) ? ssr_single({post_slug, comment_page: 1}) : spa_html );
			return;
		}
	})
	express.get('/:post_slug/comment-page-:comment_page', (req,res,next)=>{
		var comment_page = req.params.comment_page;
		var post_slug = req.params.post_slug;
		res.type("text/html");
		// res.send( "进来了" );
		res.send( is_search_engin(req) ? ssr_single({post_slug, comment_page}) : spa_html );
		return;
	})
	express.get('/:taxonomy/:term_slug', (req,res,next)=>{
		var term_slug = req.params.term_slug;
		var taxonomy = req.params.taxonomy;
		if (term_slug.includes('.')) {
			next();
		} else {
			res.type("text/html");
			// res.send( "进来了" );
			res.send( is_search_engin(req) ? ssr_term({taxonomy,term_slug,current_page:1}) : spa_html );
			return;
		}
	})
	express.get('/:taxonomy/:term_slug/page/:current_page', (req,res,next)=>{
		var term_slug = req.params.term_slug;
		var taxonomy = req.params.taxonomy;
		var current_page = req.params.current_page;
		res.type("text/html");
		// res.send( "进来了" );
		res.send( is_search_engin(req) ? ssr_term({taxonomy,term_slug,current_page}) : spa_html );
		return;
	})

	express.get('*', (req,res,next)=>{
		res.type("text/html");
		// res.send( "进来了：*" );
		res.status(404).send( is_search_engin(req) ? ssr_404() : spa_html);
		return;
	})
},99)




class Echo {
	#html = "";
	get isEmpty() {
		return !this.#html.length;
	}
	get html() {
		return this.#html;
	}
	constructor(message) {
		if (message) {
			this.#html = message;
		}
		this.attach = this.appendString.bind(this)
		return this;
	}
	appendString(sth) {
		if (typeof(sth) == 'string') {
			this.#html += sth;
		}
		else if (sth.toString && typeof(sth.toString) == 'function') {
			this.#html += sth.toString();
		}
		else {
			var tryStr = JSON.Stringify( sth );
			this.#html += tryStr ? tryStr : '__UNDEFINED__';
		}
		return this;
	}
}

function ssr_frontpage() {
	// 首页
	var echo = new Echo();
	require( path.join(__dirname,"./function-ssr-frontpage.js") )({
		echo: echo.attach,
	})
	return echo.html;
}

function ssr_single({post_slug,comment_page}) {
	// 内容页
	post_slug = encodeURIComponent(decodeURIComponent(post_slug));
	var post = get_post(post_slug);
	if ( is_nv_error(post) ) {
		return ssr_404();
	}
	if ( post.status !== "publish" || post.modified_time > new Date().getTime() ) {
		return ssr_404();
	}
	var echo = new Echo();
	require( path.join(__dirname,"./function-ssr-single.js") )({
		echo: echo.attach,
		post,
		post_slug,
		comment_page,
	})
	return echo.html;
}

function ssr_articles({current_page}) {
	// 文章时间线
	var echo = new Echo();
	require( path.join(__dirname,"./function-ssr-articles.js") )({
		echo: echo.attach,
		current_page,
	})
	return echo.html;
}

function ssr_term({taxonomy,term_slug,current_page}) {
	// 文章分类页
	var term_id = term_exists(term_slug, taxonomy);
	if (!term_id) {
		return ssr_404();
	}

	var echo = new Echo();
	require( path.join(__dirname,"./function-ssr-term.js") )({
		echo: echo.attach,
		term_id,
		taxonomy,term_slug,current_page
	})
	return echo.html;
}

function ssr_404() {
	return "<h1>404</h1><p>您访问的页面不存在</p>";
}