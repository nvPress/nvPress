module.exports = ({echo,post,post_slug,comment_page})=>{
	var site_name = get_option('nv_site_name','nvPress');
	var title = `${post.title} - ${site_name}`;
	require('./function-ssr-header')({echo,title});
	echo(`
		<h1>${post.title}</h1>
		<article>
	`);
	require('./function-ssr-block-renderer')({echo,blocks:post.content.blocks});
	echo(`</article>`);
	require('./function-ssr-footer')({echo});
}