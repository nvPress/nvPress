<template>
	<div
	class="pandastudio-video"
	:class="{
		'align-left':align=='left',
		'align-center':align=='center',
		'align-right':align=='right',
		'align-full':align=='full',
		'is-video': url,
		'is-iframe': iframe,
	}"
	>
		<div class="no-video" v-if="!url && !iframe">
			<button class="lib pt-15 pb-5 pl-5 pr-5" @click="handleSelectVideo()">
				<i class="el-icon-film mr-3"></i>从媒体库选择或上传
			</button>
			<div class="nv-input-group pt-5 pb-5 pl-5 pr-5">
				<input class="nv-input" v-model='temp_url' placeholder="视频文件URL链接..." />
				<button class="nv-button disable-animation" @click="handleConfirmUrl"><i class="el-icon-check mr-3"></i></button>
			</div>
			<div class="nv-input-group pt-5 pb-15 pl-5 pr-5">
				<input class="nv-input" v-model='temp_iframe' placeholder="在线视频iframe代码..." />
				<button class="nv-button disable-animation" @click="handleConfirmIframe"><i class="el-icon-check mr-3"></i></button>
			</div>
		</div>
		<video :controls="controls" :autoplay="autoplay" :loop="loop" v-if="url">
			<source :src="url">
		</video>
		<div v-else-if="iframe" class="iframe-wrapper relative" :style="{paddingBottom: `${100/ratio}%`}" v-html="iframe"></div>
	</div>
</template>
<script>
export default {
	name: 'pandastudio-video-block',
	components:{
	},
	data(){return {
		align: '',
		ratio: 1.778,
		url: '',
		iframe: '',
		autoplay: false,
		controls: true,
		loop: false,
		temp_url: '',
		temp_iframe: '',
	}},
	mounted() {
		// 加载默认数据
		nv.block.loadDefaultData.bind(this)();
	},
	methods: {
		handleSelectVideo() {
			nv.block.mediaSelector({
				multiple: false,
				callback: videos => {
					this.url = videos[0].urls.original;
					// editor.js的问题，可考虑优化：需要调用一次保存，否则在inner-blocks里面异步的数据会丢失，并且还会报错
					this.$emit('forceUpdate');

					this.temp_url = "";
					this.temp_iframe = "";
				}
			})
		},
		handleConfirmUrl() {
			this.url = this.temp_url;
			this.temp_url = "";
			this.iframe = "";
		},
		handleConfirmIframe() {
			this.iframe = this.temp_iframe;
			this.temp_iframe = "";
			this.url = "";
		}
	}
}
</script>
<style scoped>
.pandastudio-video.align-full {
	margin-left: -60px;
	margin-right: -60px;
}
@media (max-width: 650.5px) {
	.pandastudio-video.align-full {
		margin-left: -15px;
		margin-right: -15px;
	}
}
.pandastudio-video.is-video.align-left {
	text-align: left;
}
.pandastudio-video.is-video.align-center {
	text-align: center;
}
.pandastudio-video.is-video.align-right {
	text-align: right;
}
.pandastudio-video video {
	max-width: 100%;
}
.pandastudio-video.is-video.align-full video {
	width: 100%;
}
i {
	font-style: normal;
}
.lib {
	cursor: pointer;
	font-size: 18px;
	border: none;
	color: var(--text-color-3);
	text-shadow: 0 1px var(--white-default);
	background: transparent;

}
.lib:hover {
	color: var(--primary-color-suppl);
}
.lib i {
	font-size: 30px;
	vertical-align: middle;
}
.no-video {
	background: var(--divider-color);
	border: 1px solid var(--border-color);
	text-align: center;
	transition: .35s;
}
.iframe-wrapper {
	height: 0;
}
</style>
<style>
.pandastudio-video .iframe-wrapper > iframe {
	position: absolute;
	top: 0;
	left: 0;
	width: 100%;
	height: 100%;
	border: none;
}
</style>