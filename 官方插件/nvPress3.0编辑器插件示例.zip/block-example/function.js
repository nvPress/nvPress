var path = require("path")
add_action('init_express',()=>{
	register_static_url('/pandastudio-sample-block-srcs/', path.join(__dirname,"./public_srcs/") );
});

register_blocks('/pandastudio-sample-block-srcs/block-admin-register.js');