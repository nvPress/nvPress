// 注册路径，把 public_srcs 文件夹暴露到这个地址： http://nvpress安装地址/pandastudio-sample-block-srcs
var path = require("path")
add_action('init_express',()=>{
	register_static_url('/pandastudio-sample-block-srcs/', path.join(__dirname,"./public_srcs/") );
});

// 注册block需要的实际脚本，每次加载编辑器都会执行一次
register_blocks('/pandastudio-sample-block-srcs/block-admin-register.js');

// 编辑器服务器端渲染（为搜索引擎SSR）
add_filter(`async:render_block:block-example`,async (next, last_filtered, {data}, post)=>{
	var {
		title,
		contents,
		color,
		align
	} = data;

	// 处理内嵌的其它block
	var innerBlockText = await async_render_blocks(contents.blocks, post);

	next(`<div class="block-example" style="color: ${color}; text-align: ${align}">
		富文本：
		<div>${title}</div>
		嵌入的其它内容：
		<div>${innerBlockText}</div>
	</div>`)
})

// 由于有内嵌的其它block，因此需要写一个方法来依次渲染内嵌的其它block
var async_render_blocks = (blocks, post)=>{
	async function fn() {
		var result_content = "";
		for (var i = 0; i < blocks.length; i++) {
			var block = blocks[i];
			var block_data = await apply_async_filters(`async:render_block:${block.type}`,"", block, post);
			result_content += block_data;
		}
		return result_content;
	}
	return fn();
}

// 客户端渲染
add_action('nv_head', (req,route) => {
	nv_enqueue_script(`/pandastudio-sample-block-srcs/frontend-render.js`);
	nv_enqueue_style(`/pandastudio-sample-block-srcs/frontend-style.css`);
})