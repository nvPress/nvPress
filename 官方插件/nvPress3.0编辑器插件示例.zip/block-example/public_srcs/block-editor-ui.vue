<template>
	<div class="block-example-wrapper" :style="{color: $props.block.data.color, textAlign: $props.block.data.align}">
		富文本：
		<editorRichText v-model:value="$props.block.data.title" tag="div" nowrap />
		嵌套块：
		<editorInnerBlocks class="contents" :value="$props.block.data.contents" />
	</div>
</template>

<script setup>
var {editorRichText, editorInnerBlocks} = nv.components;
var $props = defineProps({
	block: {default: Object}
})
</script>

<style scoped>
.block-example-wrapper, .contents {
	border: 1px solid;
}
</style>