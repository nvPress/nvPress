<template>
	<editorCollapseBox title="颜色" defaultExpanded>
		<editorColorSelector v-model:value="$props.block.data.color" />
	</editorCollapseBox>
</template>

<script setup>
var {editorColorSelector, editorCollapseBox} = nv.components;
var $props = defineProps({
	block: {type: Object}
})
</script>