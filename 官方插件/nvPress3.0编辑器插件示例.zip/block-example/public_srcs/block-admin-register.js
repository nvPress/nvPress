var {register_block_type} = nv.editor.blocks;
var {_defineRemoteComponent, defineComponent} = nv.Vue;
var editor = _defineRemoteComponent("/pandastudio-sample-block-srcs/block-editor-ui.vue")
var settings = _defineRemoteComponent("/pandastudio-sample-block-srcs/block-settings-ui.vue")
var inlineTunes = _defineRemoteComponent("/pandastudio-sample-block-srcs/block-inline-tunes-ui.vue")

export default ({post_type, post_id})=>{
	register_block_type("block-example",{
		name: "block示例",
		description: "示例描述内容",
		category: 'design', // 默认的分类有：text/illustration & media/design
		icon: defineComponent({
			template: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="-100 -100 648 712" width="24" height="24"><path d="M360.2 83.8c-24.4-24.4-64-24.4-88.4 0l-184 184c-42.1 42.1-42.1 110.3 0 152.4s110.3 42.1 152.4 0l152-152c10.9-10.9 28.7-10.9 39.6 0s10.9 28.7 0 39.6l-152 152c-64 64-167.6 64-231.6 0s-64-167.6 0-231.6l184-184c46.3-46.3 121.3-46.3 167.6 0s46.3 121.3 0 167.6l-176 176c-28.6 28.6-75 28.6-103.6 0s-28.6-75 0-103.6l144-144c10.9-10.9 28.7-10.9 39.6 0s10.9 28.7 0 39.6l-144 144c-6.7 6.7-6.7 17.7 0 24.4s17.7 6.7 24.4 0l176-176c24.4-24.4 24.4-64 0-88.4z"/></svg>`
		}),
		attributes: {
			title: "",
			contents: {},
			color: "",
			align: "",
		},
		editor,
		settings,
		inlineTunes,
	})
}
