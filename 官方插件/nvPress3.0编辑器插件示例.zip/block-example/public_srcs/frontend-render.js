customElements.define('nv-block-block-example',class extends HTMLElement {
	constructor() {
		super();
		setTimeout(()=>{
			var block_data = this.data || {
				title: "",
				contents: {blocks:[]},
				color: "",
				align: "",
			};
			var wrapper = document.createElement("DIV");
			wrapper.classList.add('block-example-wrapper')
			if (block_data.color) {
				wrapper.style.color = block_data.color
			}
			if (block_data.align) {
				wrapper.style.textAlign = block_data.align
			}
			wrapper.innerHTML = `
			富文本：<div>${block_data.title}</div>
			嵌入的其它内容：`

			var innerBlocks = document.createElement('nv-block-nestedblocks')
			innerBlocks.blocks = block_data.contents.blocks

			wrapper.append(innerBlocks)

			this.append(wrapper)
		})
	}
})