<template>
	<toolbarDropdown
	:button-active="!!data.align"
	button-tooltip="文本对齐"
	v-model:show="show_REF"
	>
		<template #label>
			<IconAlignCenter v-if="data.align=='center'" />
			<IconAlignRight v-else-if="data.align=='right'" />
			<IconAlignLeft v-else />
		</template>
		<div
		@click="handleAlign('left')"
		:class="{'is-active': data.align == 'left'}"
		class="nvbe-toolbar__popwrapper-list_item">
			<button
			class="nvbe-toolbar__inline-button"
			>
				<IconAlignLeft />
			</button>
			左对齐
		</div>

		<div
		@click="handleAlign('center')"
		:class="{'is-active': data.align == 'center'}"
		class="nvbe-toolbar__popwrapper-list_item">
			<button
			class="nvbe-toolbar__inline-button"
			>
				<IconAlignCenter />
			</button>
			居中
		</div>

		<div
		@click="handleAlign('right')"
		:class="{'is-active': data.align == 'right'}"
		class="nvbe-toolbar__popwrapper-list_item">
			<button
			class="nvbe-toolbar__inline-button"
			>
				<IconAlignRight />
			</button>
			右对齐
		</div>
	</toolbarDropdown>
</template>
<script setup>
var toolbarDropdown = nv.components.editorToolbarDropdown;
import IconAlignLeft from "./icon-align-left.vue"
import IconAlignCenter from "./icon-align-center.vue"
import IconAlignRight from "./icon-align-right.vue"
import {ref} from "vue";
var $props = defineProps({
	block: {
		type: Object,
	}
})
var {data,type,id} = $props.block;
var show_REF = ref(false)

var handleAlign = position => {
	data.align = data.align == position ? '' : position;
	show_REF.value = false;
}

/*var handleCheckState = selection => {
	// 只要触发checkState，就表示可以检查inline tunes图标状态了
	// console.log('CheckState')
}*/

// 要将这个方法暴露出去，有状态变化的时候，才会call这两个方法
/*defineExpose({
	checkState: handleCheckState,
})*/
</script>