<template>
	<div
	class="pandastudio-article-link"
	:data-opennew="opennew"
	:data-post-id="post_id"
	>
		<div class="post-wrapper flex justify-center">
			<div class="post flex" @click="handleOpenModal" v-if="post_id">
				<div class="thumbnail" :style="{backgroundImage:`url(${post.metas._nv_thumbnail || post.metas.banner})`}"></div>
				<div class="info">
					<div class="title">{{post.title || '无标题'}}</div>
					<div class="date">
						<i class="el-icon-time"></i> {{timestamp2date(post.modified_time)}}
					</div>
				</div>
			</div>
			<div class="post no-post-selected flex" @click="handleOpenModal" v-else>
				请选择文章
			</div>
		</div>
		<n-modal v-model:show="show_modal" preset="dialog" :show-icon="false">
			<template #header>
				<div>请选择文章</div>
			</template>
			<n-element>
				<n-input-group>
					<n-input v-model:value="keyword" placeholder="请输入关键字..." @keydown.enter="handle_query" />
					<n-button type="primary" ghost @click="handle_query">
						搜索
					</n-button>
				</n-input-group>
				<ul>
					<li v-for="post in posts" :class="{selected: selected_id == post.id}" @click="selected_id = post.id" @dblclick="post_id = post.id,show_modal=false">
						{{post.title}}
					</li>
				</ul>
			</n-element>
			<template #action>
				<n-element>
					<button class="nv-button primary wider" @click="handleConfirm" :disabled="!selected_id"><i class="el-icon-check mr-3"></i>确定</button>
				</n-element>
			</template>
		</n-modal>
	</div>
</template>
<script>
export default {
	name: 'pandastudio-article-link',
	data(){return {
		post_id: 0,
		opennew: false,
		show_modal: false,
		selected_id: 0,
		keyword: "",
		posts: [],
		post: {
			metas: {

			}
		},
	}},
	components: {
		nModal: nv.components.modal,
		nElement: nv.components.element,
		nInput: nv.components.input,
		nInputGroup: nv.components.inputGroup,
		nButton: nv.components.button,
	},
	mounted() {
		// 加载默认数据，不要问为什么。做就行了：
		nv.block.loadDefaultData.bind(this)();
	},
	watch: {
		post_id(val) {
			// 异步改变了数据，就要forceUpdate一下，别问为什么。做就行了
			this.$emit('forceUpdate');

			nv.$axios({
				method: 'post',
				url: nv.$API + '/pandastudio/block/article-link',
				responseType: 'json',
				data:{ id:this.post_id },
			})
			.then(({data})=>{
				this.post = data;
			})
			.catch((error)=>{
				$message.error('网络访问错误！')
			})
		}
	},
	methods: {
		handleOpenModal() {
			this.show_modal = true;
			this.selected_id = 0;
			if (!this.posts.length) {
				this.handle_query();
			}
		},
		handle_query() {
			nv.$axios({
				method: 'post',
				url: nv.$API + "/nv/front-stage/get-post-list",
				headers: {'X-Requested-With': 'XMLHttpRequest'},
				responseType: 'json',
				data:{
					post_type: ['page','article'],
					keyword: this.keyword,
				},
			})
			.then(({data})=>{
				this.posts = data.data;
			})
			.catch((error)=>{
				$message.error('网络访问错误！')
			})
		},
		handleConfirm() {
			this.post_id = this.selected_id;
			this.show_modal = false;
		},
		timestamp2date(timestamp) {
			var timestr = new Date(timestamp);
			var year = timestr.getFullYear();
			var month = timestr.getMonth()+1;
			var date = timestr.getDate();
			return `${year || '0000'}-${month || '00'}-${date || '00'}`;
		}
	}
}
</script>
<style scoped>
ul {
	padding: 0;
	margin: 1em 0;
}
li {
	display: block;
	list-style: none;
	border: 1px solid transparent;
	padding: .25em 1em;
	border-radius: 4px;
	cursor: pointer;
	transition: .25s;
}
li:hover {
	color: var(--primary-color);
	background-color: var(--primary-opacity-1);
	transition: 0s;
}
li.selected {
	border-color: var(--primary-opacity-5);
	color: var(--primary-color);
	background-color: var(--primary-opacity-1);
}
.post-wrapper .thumbnail {
	width: 92px;
	height: 82px;
	background-position: center;
	background-size: cover;
	flex-shrink: 0;
	border-radius: .825em;
}
.post-wrapper .post {
	background: var(--white-default);
	box-shadow: 0 .5em .5em rgba(0,0,0,.03);
	padding: .125em;
	border-radius: 1em;
	border: 1px solid var(--divider-color);
	cursor: pointer;
}
.post-wrapper .info {
	display: flex;
	padding: .125em 1em;
	justify-content: center;
	flex-direction: column;
}
.post-wrapper .date {
	font-size: 80%;
	color: var(--text-color-3);
	margin-top: .5em;
}
.post-wrapper .title {
	font-size: 17px;
	color: var(--gray-2);
	text-shadow: 2px 2px 2px var(--gray-opacity-1);
}
</style>