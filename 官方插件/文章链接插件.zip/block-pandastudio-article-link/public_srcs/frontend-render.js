customElements.define('nv-block-pandastudio-article-link',class extends HTMLElement {
	constructor() {
		super();
		Vue.nextTick(()=>{
			// 获取的值
			var block_data = this.data || {
				post_id: 0,
				opennew: false
			};
			Vue.createApp({
				template: `<div class="block-pandastudio-article-link" v-if="data.post_id && post.id">
					<a class="post" :href="post.permalink" :target="data.opennew ? '_blank' : '_self'">
						<span class="thumbnail" :style="{backgroundImage:\`url(\${post.metas._nv_thumbnail || post.metas.banner})\`}"></span>
						<span class="info">
							<span class="title">{{post.title || '无标题'}}</span>
							<span class="date">
								<i class="fa-regular fa-clock"></i> {{timestamp2date(post.modified_time)}}
							</span>
						</span>
					</a>
				</div>`,
				data(){return{
					data: block_data,
					post: {id: 0, metas: {} },
				}},
				mounted() {
					if (this.data.post_id) {
						fetch("/pandastudio/block/article-link/",{
							method: 'post',
							body: JSON.stringify({id: this.data.post_id}),
							headers: { "Content-Type": "application/json" }
						})
						.then( response => response.json() )
						.then( data => {
							if (!data.error) {
								this.post = data;
							}
						})
						.catch( e=>{console.log(e)} )
					}
				},
				methods: {
					timestamp2date(timestamp) {
						var timestr = new Date(timestamp);
						var year = timestr.getFullYear();
						var month = timestr.getMonth()+1;
						var date = timestr.getDate();
						return `${year || '0000'}-${month || '00'}-${date || '00'}`;
					},
				},
			}).mount(this)
		})
	}
})