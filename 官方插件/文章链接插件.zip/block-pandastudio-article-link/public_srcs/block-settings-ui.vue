<template>
	<div class="tune-box border-bottom" style="width: 120px">
		<div class="flex justify-between">
			<nCheckbox v-model:checked="opennew">新窗口打开</nCheckbox>
		</div>
	</div>
</template>
<script>
export default {
	name: 'pandastudio-sample-block-settings',
	components:{
		nCheckbox: nv.components.checkbox
	},
	data(){return{
		post_id: 0,
		opennew: false,
	}},
	mounted() {
		// 加载默认数据
		nv.block.loadDefaultData.bind(this)();
	},
}
</script>