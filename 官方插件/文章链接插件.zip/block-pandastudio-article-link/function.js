var path = require("path")

// 注册静态路径
add_action('init_express',()=>{
	register_static_url('/block-pandastudio-article-link-srcs/', path.join(__dirname,"./public_srcs/") );
});

// 注册编辑器块
var block_type = "pandastudio/article-link";
register_editor_block(block_type,['article'],'/block-pandastudio-article-link-srcs/block-admin-register.js');

// 编辑器服务器端渲染（为搜索引擎SSR）
add_filter(`async:render_block:${block_type}`,async (next, last_filtered, {data}, post)=>{
	var {
		post_id,
		opennew,
	} = data;
	var post = get_post(post_id);
	if (is_nv_error(post)) { next(""); return;}

	var { _nv_thumbnail, banner } = get_post_meta(post_id);
	var permalink = get_post_permalink(post);
	var timestamp2date = timestamp =>{
		var timestr = new Date(timestamp);
		var year = timestr.getFullYear();
		var month = timestr.getMonth()+1;
		var date = timestr.getDate();
		return `${year || '0000'}-${month || '00'}-${date || '00'}`;
	}

	next(`<div class="block-pandastudio-article-link">
		<a class="post" href="${permalink}" target="${opennew ? '_blank' : '_self'}">
			<span class="thumbnail" style="background-image:url(${_nv_thumbnail || banner})"></span>
			<span class="info">
				<span class="title">${post.title || '无标题'}</span>
				<span class="date">
					<i class="fa-regular fa-clock"></i> ${timestamp2date(post.modified_time)}
				</span>
			</span>
		</a>
	</div>`);
})

// 添加头文件
add_action('nv_head', (req,route) => {
	nv_enqueue_script(`/block-pandastudio-article-link-srcs/vue.global.prod.v3.2.45.js`, 'vue.global', '3.2.45');
	nv_enqueue_script(`/block-pandastudio-article-link-srcs/frontend-render.js`);
	nv_enqueue_style(`/block-pandastudio-article-link-srcs/frontend-style.css`);
})

// 接口
register_rest_route('pandastudio','block/article-link',{
	methods: 'post',
	callback(data,req) {
		const {id} = data;
		if (!id) {
			return new NV_Error('参数错误');
		}

		var post = get_post(id);
		if (is_nv_error(post)) {
			return post;
		}

		return {
			id: post.id,
			title: post.title,
			excerpt: post.excerpt,
			modified_time: post.modified_time,
			comment_count: post.comment_count,
			post_type: post.post_type,
			metas: get_post_meta(id),
			permalink: get_post_permalink(post),
		}
	}
});