var path = require("path")

// 注册静态路径
add_action('init_express',()=>{
	register_static_url('/nirvana-extra-blocks/', path.join(__dirname,"./dist/") );
});

// 注册编辑器块
register_blocks('/nirvana-extra-blocks/editor.js')

// 添加头文件
add_action('nv_head', (req,route) => {
	// 主题没有将 vue 暴露出来，因此引入一个vue
	nv_enqueue_script(`/nirvana-extra-blocks/vue.global.prod.v3.2.45.js`, 'vue.global', '3.2.45');
	// 打包好的 web-components
	nv_enqueue_script(`/nirvana-extra-blocks/web-components.js`);
	nv_enqueue_style(`/nirvana-extra-blocks/web-components.css`);
})

// 服务器端渲染（ 搜索引擎 SEO ）
require('./function-ssr.js')

// 下载按钮评论可见
var fix_block_data = (sth, fix_handlers) => {
	var object_is_editor = obj => obj && Array.isArray(obj.blocks) && obj.blocks.every(block=>block.id && block.type && block.data)
	var find_target_in = arr_or_obj =>{
		if (!arr_or_obj) {return;}

		if ( Array.isArray(arr_or_obj) ) {
			arr_or_obj.forEach((item,index)=>{
				if (object_is_editor(item)) {
					item.blocks.forEach(block=>{
						if ( fix_handlers[block.type] ) {
							fix_handlers[block.type](block);
						} else {
							find_target_in(block)
						}
					})
				} else {
					find_target_in(item)
				}
			})
		} else if(typeof(arr_or_obj) == 'object') {
			Object.keys(arr_or_obj).forEach(key=>{
				var item = arr_or_obj[key];
				if (object_is_editor(item)) {
					item.blocks.forEach(block=>{
						if ( fix_handlers[block.type] ) {
							fix_handlers[block.type](block);
						} else {
							find_target_in(block)
						}
					})
				} else {
					find_target_in(item)
				}
			})
		}
	}
	
	if ( object_is_editor(sth) ) {
		sth.blocks.forEach(block=>{
			if ( fix_handlers[block.type] ) {
				fix_handlers[block.type](block);
			} else {
				find_target_in(block)
			}
		})
	}
	find_target_in(sth);
}

// 需要对文章结果进行处理。以实现评论后可见
add_filter('rest_send_post:/nv/front-stage/get-post', (send_data, req)=>{
	if ( is_nv_error(send_data) ) {
		return send_data;
	}

	// 处理评论可见
	var current_user_email = get_user_by_nonce(req.headers.nvnonce).email || req.body.email;
	var is_current_user_replied = current_user_email
								?
								query_comments({
									email: current_user_email,
									post: send_data.id
								}).pagination.total
								: false;
	// 处理文章 content，并且循环处理子block。方法可能有性能问题，待优化
	fix_block_data(send_data.content,{
		'pandastudio/download'(block) {
			if (block.data.need_reply && !is_current_user_replied) {
				block.data.url = '';
				block.data.links.forEach(link=>{
					link.url = '';
				})
			} else {
				block.data.need_reply = false;
			}
		}
	})
	return send_data;
})