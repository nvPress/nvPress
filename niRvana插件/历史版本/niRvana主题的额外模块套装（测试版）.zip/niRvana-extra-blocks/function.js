var path = require("path")

// 注册静态路径
add_action('init_express',()=>{
	register_static_url('/nirvana-extra-blocks/', path.join(__dirname,"./dist/") );
});

// 注册编辑器块
register_blocks('/nirvana-extra-blocks/editor.js')

// 添加头文件
add_action('nv_head', (req,route) => {
	nv_enqueue_script(`/nirvana-extra-blocks/vue.global.prod.v3.2.45.js`, 'vue.global', '3.2.45');
	nv_enqueue_script(`/nirvana-extra-blocks/web-components.js`);
	nv_enqueue_style(`/nirvana-extra-blocks/web-components.css`);
})

// 服务器端渲染（ 搜索引擎 SEO ）
require('./function-ssr.js')